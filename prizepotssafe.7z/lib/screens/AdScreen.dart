import 'dart:math';
import 'package:prizepots/screens/PrettyButton.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ads/ads.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/animation.dart';
import 'package:animator/animator.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:firebase_admob/firebase_admob.dart';
import 'dart:io';
import 'dart:convert';
import 'package:prizepots/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AdScreen extends StatefulWidget {
  AdScreen({Key key, this.animate, this.appAds, this.randomInt, this.generatedPoints, this.coindivider}) : super(key: key);
  bool animate;
  Ads appAds;
  int randomInt;
  double generatedPoints;
  double coindivider;

  @override
  _AdScreenState createState() => new _AdScreenState();
}

class _AdScreenState extends State<AdScreen>
    with TickerProviderStateMixin {

  int points = 0;
  double generatedPoints = 0;
  int sizeDivider = 10;
  final int max = 1000;
  double screen;
  double factor;
  SharedPreferences sharedPreferences;
  AnimationController rotationController;
  AnimationController animationController;
  Random rnd = Random();
  String userID;
  double multiplier = 1.2;
  bool disabled;
  DateTime timestamp;
  double coindivider = 2;
  static final int qualifyForWeekly = 5;
  static final int qualifyForMonthly = 3;
  static final int qualifyForYearly = 10;

  final String videoUnitId = Platform.isAndroid
      ? 'ca-app-pub-3940256099942544/5224354917'
      : 'ca-app-pub-3940256099942544/1712485313';



  @override
  void initState() {
    super.initState();
//    var eventListener = (MobileAdEvent event) {};
    rotationController = AnimationController(duration: const Duration(milliseconds: 5000), vsync: this);
    animationController = AnimationController(duration: const Duration(milliseconds: 5000), vsync: this);
    rotationController.repeat();

    SharedPreferences.getInstance().then(
      (SharedPreferences sp) {
        sharedPreferences = sp;

        points = sharedPreferences.getInt("Points");
        userID = sharedPreferences.getString("userID");

        if (sharedPreferences.getBool("firstLoginAd")) {
          _showIntroDialog();
        }

        setState(() {});

//        if (!adInstantiated) {
//          adInstantiated = true;
//          appAds = Ads(
//            appId,
//            bannerUnitId: bannerUnitId,
//            screenUnitId: screenUnitId,
//            keywords: <String>['ibm', 'computers'],
//            contentUrl: 'http://www.ibm.com',
//            childDirected: false,
//            testDevices: ['Samsung_Galaxy_SII_API_26:5554'],
//            testing: false,
//            listener: eventListener,
//          );
//        }

        widget.appAds.setVideoAd(
            adUnitId: videoUnitId,
            keywords: ['dart', 'java'],
            contentUrl: 'http://www.publang.org',
            childDirected: true,
            testDevices: null,
            listener: (RewardedVideoAdEvent event,
                {String rewardType, int rewardAmount}) {
              print(event);

              if (event == RewardedVideoAdEvent.started) {
                generatedPoints = 2000;
                points = points + generatedPoints.toInt();
              }
              if (event == RewardedVideoAdEvent.rewarded) {
                generatedPoints = 25;
                points = points + generatedPoints.toInt();
              }
              if (event == RewardedVideoAdEvent.leftApplication) {
                generatedPoints = 50;
                points = points + generatedPoints.toInt();
              }
              sharedPreferences.setInt("Points", points);

              if (points > 0) {
                if (points <= 1000) {
                  coindivider = 2.325;
                } else if (points <= 2000) {
                  coindivider = 1.675;
                } else if (points <= 3000) {
                  coindivider = 3.86;
                } else if (points <= 4000) {
                  coindivider = 1.3;
                } else {
                  coindivider = 11.25;
                }
              }
              if (event == RewardedVideoAdEvent.closed) {

                widget.appAds.dispose();
                animationController.dispose();
                rotationController.dispose();
                Navigator.pushReplacement(
                    context,
                    PageRouteBuilder(
                      pageBuilder: (c, a1, a2) => new AdScreen(animate: true, appAds: widget.appAds, generatedPoints: generatedPoints, coindivider: coindivider),
                      transitionsBuilder: (c, anim, a2, child) => FadeTransition(opacity: anim, child: child),
                      transitionDuration: Duration(milliseconds: 500),
                    ));
              }
            });
      },
    );
  }

  void _showIntroDialog() {
    showDialog(
        context: context,
        child: Container(
            width: MediaQuery
                .of(context)
                .size
                .width,
            height: MediaQuery
                .of(context)
                .size
                .height,
            decoration: BoxDecoration(
                border: Border.all(color: Colors.white.withOpacity(1.0)),
                borderRadius: BorderRadius.all(Radius.circular(40))),
            child: new AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40)),
              backgroundColor: Colors.black.withOpacity(1),
              title: new Text("Earn Points",
                  style: TextStyle(color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold)),
              content: new Text (
                "1. Once you hit the Button 'Show Ad' an Ad will pop up. \n\n2. You earn points for interacting with the Ad. \nHint: Some interactions give you more points than others. \n\n3. Once you reached enough points, you can participate in the distribution \n\n4. Participation is allowed only once per day, but you can earn as much points as you want. Your points stay valid and can be used for any following days.",
                style: TextStyle(color: Colors.white, fontSize: 18),),
              actions: <Widget>[
                new RaisedButton(
                  child: Text("Ok"),
                  color: Colors.green,
                  colorBrightness: Brightness.dark,
                  onPressed: () {
                    sharedPreferences.setBool("firstLoginAd", false);
                    Navigator.of(context, rootNavigator: true).pop();
                  },
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0)),
                ),
              ],
            )));
  }

  void _qualifyUserForPrizepots() async {
    String qualifyWeeklyUrl = "https://4bik97sfud.execute-api.eu-central-1.amazonaws.com/Login/jackpot/weekly/qualify";
    String qualifyWeeklyJson = '{"UserID": "' +
        userID +
        '", "Timestamp": "' +
        timestamp.toString() +
        '"}';

    await http.post(qualifyWeeklyUrl, body: qualifyWeeklyJson);

    String urlUserWeekly = "https://4bik97sfud.execute-api.eu-central-1.amazonaws.com/Login/jackpot/weekly/" + userID;
    http.Response responseWeekly = await http.get(urlUserWeekly);
    final decodedWeekly = jsonDecode(responseWeekly.body) as Map;
    int qualifyCountWeekly = decodedWeekly['Count'];

    if (qualifyCountWeekly == qualifyForWeekly) {

      String url = "https://4bik97sfud.execute-api.eu-central-1.amazonaws.com/Login/jackpot/weekly";
      String json = '{"UserID": "' +
          userID +
          '"}';
      await http.post(url, body: json);

      String qualifyMonthlyUrl = "https://4bik97sfud.execute-api.eu-central-1.amazonaws.com/Login/jackpot/monthly/qualify";
      String qualifyMonthlyJson = '{"UserID": "' +
          userID +
          '", "Timestamp": "' +
          timestamp.toString() +
          '"}';
      await http.post(qualifyMonthlyUrl, body: qualifyMonthlyJson);

      String urlUserMonthly = "https://4bik97sfud.execute-api.eu-central-1.amazonaws.com/Login/jackpot/weekly/" + userID;
      http.Response responseMonthly = await http.get(urlUserMonthly);
      final decodedMonthly = jsonDecode(responseMonthly.body) as Map;
      int qualifyCountMonthly = decodedMonthly['Count'];

      if (qualifyCountMonthly == qualifyForMonthly) {
        String url = "https://4bik97sfud.execute-api.eu-central-1.amazonaws.com/Login/jackpot/monthly";
        String json = '{"UserID": "' +
            userID +
            '"}';
        await http.post(url, body: json);

        String qualifyYearlyUrl = "https://4bik97sfud.execute-api.eu-central-1.amazonaws.com/Login/jackpot/yearly/qualify";
        String qualifyYearlyJson = '{"UserID": "' +
            userID +
            '", "Timestamp": "' +
            timestamp.toString() +
            '"}';
        await http.post(qualifyYearlyUrl, body: qualifyYearlyJson);

        String urlUserYearly = "https://4bik97sfud.execute-api.eu-central-1.amazonaws.com/Login/jackpot/yearly/" + userID;
        http.Response responseYearly = await http.get(urlUserYearly);
        final decodedYearly = jsonDecode(responseYearly.body) as Map;
        int qualifyCountYearly = decodedYearly['Count'];

        if (qualifyCountYearly == qualifyForYearly) {
          String url =
              "https://4bik97sfud.execute-api.eu-central-1.amazonaws.com/Login/jackpot/yearly";
          String json = '{"UserID": "' +
              userID +
              '"}';
          await http.post(url, body: json);
        }
      }
    }

  }
  void _addUserToPrizepot() async {

    String urlUser = "https://4bik97sfud.execute-api.eu-central-1.amazonaws.com/Login/jackpot/daily/" + userID;
    http.Response responseParticipate = await http.get(urlUser);
    final decodedParticipate = jsonDecode(responseParticipate.body) as Map;
    int participate = decodedParticipate['Count'];
    timestamp = DateTime.now().toUtc();

    if (participate == null || participate == 0) {
      String url =
          "https://4bik97sfud.execute-api.eu-central-1.amazonaws.com/Login/jackpot/daily";

      String json = '{"UserID": "' +
          userID +
          '"}';

      _qualifyUserForPrizepots();

      http.Response response = await http.post(url, body: json);

      if (response.statusCode == 201) {
        points = points - max;
        sharedPreferences.setInt("Points", points);
        Fluttertoast.showToast(
            msg:
            "Looks like someone is about to win today! Congrats and thanks for helping!",
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIos: 1,
            backgroundColor: Colors.green,
            textColor: textColor,
            fontSize: 15.0);
      }
    } else {
      Fluttertoast.showToast(
          msg:
          "You are already participating today",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIos: 1,
          backgroundColor: Colors.green,
          textColor: textColor,
          fontSize: 15.0);
    }

    setState(() {

    });

  }

  @override
  void dispose() {
//    widget.appAds.dispose();
//  animationController.dispose();
//  rotationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    screen = MediaQuery.of(context).size.height - 120;
    factor = max / screen;
    if (points == null) {
      points = 0;
    }


    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
          backgroundColor: Colors.black,
          title: Center(
              child: Container(height: 130,child: Image.asset("assets/logowhitelong.png", fit: BoxFit.contain))
//              child: Text("ADs for Future",
//                  style: TextStyle(
//                    fontFamily: 'ColaborateThin',
//                    fontWeight: FontWeight.w300,
//                    fontSize: 30.0,
//                    fontStyle: FontStyle.italic,
//                    color: color3,
//                    letterSpacing: 0.5,
//                  ))
      )),
      body: Stack(
        children: <Widget>[
          RotationTransition(
            turns: Tween(begin: 0.5, end: 1.0).animate(rotationController),
            child: Padding (padding: EdgeInsets.only(right: 0), child: Align(alignment: Alignment.center, child: Container(
              height: widget.generatedPoints != null ? 0 : 0,
//              widget.generatedPoints != null ? 0 : 0,
              color: Colors.transparent,
              child: Opacity(
                opacity: 1,
                child: Image.asset('assets/coin.png',
                    fit: BoxFit.cover),
              ),
            ),),),),
    Opacity(opacity: widget.animate != null && points < 5000 && points > 0 ? 1.0 : 0.0,
    child: Animator(
    tween: Tween<Offset>(begin: Offset((MediaQuery.of(context).size.width / 50) / widget.coindivider, 0), end: Offset((MediaQuery.of(context).size.width / 50) / widget.coindivider, MediaQuery.of(context).size.height / 50)),
//              : points > 1000 && points <= 2000 ? Tween<Offset>(begin: Offset((MediaQuery.of(context).size.width / 50) / 1, 0), end: Offset((MediaQuery.of(context).size.width / 50) / 1.2, MediaQuery.of(context).size.height / 50))
//              : points > 2000 && points <= 3000 ? Tween<Offset>(begin: Offset((MediaQuery.of(context).size.width / 50) / 2.8, 0), end: Offset((MediaQuery.of(context).size.width / 50) / 2.8, MediaQuery.of(context).size.height / 50))
//              : points > 3000 && points <= 4000 ? Tween<Offset>(begin: Offset((MediaQuery.of(context).size.width / 50) / 0.4, 0), end: Offset((MediaQuery.of(context).size.width / 50) / 0.4, MediaQuery.of(context).size.height / 50))
//              : points > 4000 && points <= 5000 ? Tween<Offset>(begin: Offset((MediaQuery.of(context).size.width / 50) / 13.5, 0), end: Offset((MediaQuery.of(context).size.width / 50) / 13.5, MediaQuery.of(context).size.height / 50))

    duration: Duration(seconds: 5),
    cycles: 1, builder: (anim) =>
    SlideTransition(position: anim,
    child: Animator(
    tween: Tween<double>(begin: 0, end: 50),
    duration: Duration(milliseconds: 100000),
    repeats: 0,
    builder:

    (anim) =>
    Transform.rotate(angle: anim.value, child: Animator(
    tween: Tween<double>(begin: 0, end: 700),
    duration: Duration(milliseconds: 100000),
    repeats: 0,
    builder:

    (anim) =>
    Transform(
    transform: Matrix4.rotationX(anim.value),
    alignment: Alignment.center,
    child: Container(
    height: 50,
//                widget.generatedPoints,
//            width: MediaQuery.of(context).size.width / 3,
    color: Colors.transparent,
    child: Opacity(
    opacity: 1,
    child: Image.asset('assets/coin.png',
    fit: BoxFit.cover),
    ),
    )))))))),


          Opacity (opacity: points <= 4000 ? 0.0 : points > 4100 ? 1.0 : ((points - 4000) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: 10000,)),
          Opacity (opacity: points <= 4100 ? 0.0 : points > 4200 ? 1.0 : ((points - 4100) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier,)),
          Opacity (opacity: points <= 4200 ? 0.0 : points > 4300 ? 1.0 : ((points - 4200) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 2,)),
          Opacity (opacity: points <= 4300 ? 0.0 : points > 4400 ? 1.0 : ((points - 4300) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 3,)),
          Opacity (opacity: points <= 4400 ? 0.0 : points > 4500 ? 1.0 : ((points - 4400) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 4,)),
          Opacity (opacity: points <= 4500 ? 0.0 : points > 4600 ? 1.0 : ((points - 4500) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 5,)),
          Opacity (opacity: points <= 4600 ? 0.0 : points > 4700 ? 1.0 : ((points - 4600) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 6,)),
          Opacity (opacity: points <= 4700 ? 0.0 : points > 4800 ? 1.0 : ((points - 4700) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 7,)),
          Opacity (opacity: points <= 4800 ? 0.0 : points > 4900 ? 1.0 : ((points - 4800) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 8,)),
          Opacity (opacity: points <= 4900 ? 0.0 : points > 5000 ? 1.0 : ((points - 4900) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 9,)),
          
          Opacity (opacity: points <= 3000 ? 0.0 : points > 3100 ? 1.0 : ((points - 3000) * 0.01), child:
          CoinStack(left: 0, right: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: 10000,)),
          Opacity (opacity: points <= 3100 ? 0.0 : points > 3200 ? 1.0 : ((points - 3100) * 0.01), child:
          CoinStack(left: 0, right: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier,)),
          Opacity (opacity: points <= 3200 ? 0.0 : points > 3300 ? 1.0 : ((points - 3200) * 0.01), child:
          CoinStack(left: 0, right: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 2,)),
          Opacity (opacity: points <= 3300 ? 0.0 : points > 3400 ? 1.0 : ((points - 3300) * 0.01), child:
          CoinStack(left: 0, right: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 3,)),
          Opacity (opacity: points <= 3400 ? 0.0 : points > 3500 ? 1.0 : ((points - 3400) * 0.01), child:
          CoinStack(left: 0, right: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 4,)),
          Opacity (opacity: points <= 3500 ? 0.0 : points > 3600 ? 1.0 : ((points - 3500) * 0.01), child:
          CoinStack(left: 0, right: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 5,)),
          Opacity (opacity: points <= 3600 ? 0.0 : points > 3700 ? 1.0 : ((points - 3600) * 0.01), child:
          CoinStack(left: 0, right: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 6,)),
          Opacity (opacity: points <= 3700 ? 0.0 : points > 3800 ? 1.0 : ((points - 3700) * 0.01), child:
          CoinStack(left: 0, right: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 7,)),
          Opacity (opacity: points <= 3800 ? 0.0 : points > 3900 ? 1.0 : ((points - 3800) * 0.01), child:
          CoinStack(left: 0, right: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 8,)),
          Opacity (opacity: points <= 3900 ? 0.0 : points > 4000 ? 1.0 : ((points - 3900) * 0.01), child:
          CoinStack(left: 0, right: MediaQuery.of(context).size.width / 13.5, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 9,)),

          Opacity (opacity: points <= 2000 ? 0.0 : points > 2100 ? 1.0 : ((points - 2000) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: 10000,)),
          Opacity (opacity: points <= 2100 ? 0.0 : points > 2200 ? 1.0 : ((points - 2100) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier,)),
          Opacity (opacity: points <= 2200 ? 0.0 : points > 2300 ? 1.0 : ((points - 2200) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 2,)),
          Opacity (opacity: points <= 2300 ? 0.0 : points > 2400 ? 1.0 : ((points - 2300) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 3,)),
          Opacity (opacity: points <= 2400 ? 0.0 : points > 2500 ? 1.0 : ((points - 2400) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 4,)),
          Opacity (opacity: points <= 2500 ? 0.0 : points > 2600 ? 1.0 : ((points - 2500) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 5,)),
          Opacity (opacity: points <= 2600 ? 0.0 : points > 2700 ? 1.0 : ((points - 2600) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 6,)),
          Opacity (opacity: points <= 2700 ? 0.0 : points > 2800 ? 1.0 : ((points - 2700) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 7,)),
          Opacity (opacity: points <= 2800 ? 0.0 : points > 2900 ? 1.0 : ((points - 2800) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 8,)),
          Opacity (opacity: points <= 2900 ? 0.0 : points > 3000 ? 1.0 : ((points - 2900) * 0.01), child:
          CoinStack(right: 0, left: MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomLeft, multiplier: multiplier / 9,)),

          Opacity (opacity: points <= 1000 ? 0.0 : points > 1100 ? 1.0 : ((points - 1000) * 0.01), child:
          CoinStack(left: 0, right:MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: 10000,)),
          Opacity (opacity: points <= 1100 ? 0.0 : points > 1200 ? 1.0 : ((points - 1100) * 0.01), child:
          CoinStack(left: 0, right:MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier,)),
          Opacity (opacity: points <= 1200 ? 0.0 : points > 1300 ? 1.0 : ((points - 1200) * 0.01), child:
          CoinStack(left: 0, right:MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 2,)),
          Opacity (opacity: points <= 1300 ? 0.0 : points > 1400 ? 1.0 : ((points - 1300) * 0.01), child:
          CoinStack(left: 0, right:MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 3,)),
          Opacity (opacity: points <= 1400 ? 0.0 : points > 1500 ? 1.0 : ((points - 1400) * 0.01), child:
          CoinStack(left: 0, right:MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 4,)),
          Opacity (opacity: points <= 1500 ? 0.0 : points > 1600 ? 1.0 : ((points - 1500) * 0.01), child:
          CoinStack(left: 0, right:MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 5,)),
          Opacity (opacity: points <= 1600 ? 0.0 : points > 1700 ? 1.0 : ((points - 1600) * 0.01), child:
          CoinStack(left: 0, right:MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 6,)),
          Opacity (opacity: points <= 1700 ? 0.0 : points > 1800 ? 1.0 : ((points - 1700) * 0.01), child:
          CoinStack(left: 0, right:MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 7,)),
          Opacity (opacity: points <= 1800 ? 0.0 : points > 1900 ? 1.0 : ((points - 1800) * 0.01), child:
          CoinStack(left: 0, right:MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 8,)),
          Opacity (opacity: points <= 1900 ? 0.0 : points > 2000 ? 1.0 : ((points - 1900) * 0.01), child:
          CoinStack(left: 0, right:MediaQuery.of(context).size.width / 4.1, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomRight, multiplier: multiplier / 9,)),
          
          Opacity (opacity: points <= 0 ? 0.0 : points > 100 ? 1.0 : ((points - 0) * 0.01), child:
          CoinStack(left: 0.0, right: 0.0, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomCenter, multiplier: 10000,)),
          Opacity (opacity: points <= 100 ? 0.0 : points > 200 ? 1.0 : ((points - 100) * 0.01), child:
          CoinStack(left: 0.0, right: 0.0, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomCenter, multiplier: multiplier,)),
          Opacity (opacity: points <= 200 ? 0.0 : points > 300 ? 1.0 : ((points - 200) * 0.01), child:
          CoinStack(left: 0.0, right: 0.0, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomCenter, multiplier: multiplier / 2,)),
          Opacity (opacity: points <= 300 ? 0.0 : points > 400 ? 1.0 :  ((points - 300) * 0.01), child:
          CoinStack(left: 0.0, right: 0.0, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomCenter, multiplier: multiplier / 3,)),
          Opacity (opacity: points <= 400 ? 0.0 : points > 500 ? 1.0 : ((points - 400) * 0.01), child:
          CoinStack(left: 0.0, right: 0.0, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomCenter, multiplier: multiplier / 4,)),
          Opacity (opacity: points <= 500 ? 0.0 : points > 600 ? 1.0 : ((points - 500) * 0.01), child:
          CoinStack(left: 0.0, right: 0.0, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomCenter, multiplier: multiplier / 5,)),
          Opacity (opacity: points <= 600 ? 0.0 : points > 700 ? 1.0 : ((points - 600) * 0.01), child:
          CoinStack(left: 0.0, right: 0.0, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomCenter, multiplier: multiplier / 6,)),
          Opacity (opacity: points <= 700 ? 0.0 : points > 800 ? 1.0 : ((points - 700) * 0.01), child:
          CoinStack(left: 0.0, right: 0.0, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomCenter, multiplier: multiplier / 7,)),
          Opacity (opacity: points <= 800 ? 0.0 : points > 900 ? 1.0 : ((points - 800) * 0.01), child:
          CoinStack(left: 0.0, right: 0.0, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomCenter, multiplier: multiplier / 8,)),
          Opacity (opacity: points <= 900 ? 0.0 : points > 1000 ? 1.0 : ((points - 900) * 0.01), child:
          CoinStack(left: 0.0, right: 0.0, points: points, max: max, sizeDivider: sizeDivider, factor: factor, alignment: Alignment.bottomCenter, multiplier: multiplier / 9,)),




//          Align(alignment: Alignment.bottomLeft, child: Container(
//            height: points <= max ? points / factor / sizeDivider : MediaQuery.of(context).size.height / sizeDivider,
////            width: MediaQuery.of(context).size.width / 3,
//            color: Colors.transparent,
//            child: Opacity(
//              opacity: 1,
//              child: Image.asset('assets/coins.png',
//                  height: MediaQuery.of(context).size.height,
//                  fit: BoxFit.cover),
//            ),
//          ),),
//          Align(alignment: Alignment.bottomRight, child: Container(
//            height: points <= max ? points / factor / sizeDivider : MediaQuery.of(context).size.height / sizeDivider ,
////            width: MediaQuery.of(context).size.width / 3,
//            color: Colors.transparent,
//            child: Opacity(
//              opacity: 1,
//              child: Image.asset('assets/coins.png',
//                  height: MediaQuery.of(context).size.height,
//                  fit: BoxFit.cover),
//            ),
//          ),),
//          Align(alignment: Alignment.bottomCenter, child: Container(height: points > max ? 168 : 0, width: 100,
//            color: Colors.black,
//            child: Opacity(
//              opacity: points >= max ? 1 : 0,
//              child: Image.asset('assets/rocketfire.png',
//                  height: MediaQuery.of(context).size.height,
//                  fit: BoxFit.cover),
//            ),
//          ),),
          Container(
              decoration: new BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(10.0)),
              height: points <= max ? (max - points) / factor : 0,
              width: MediaQuery.of(context).size.width,
              child: SizedBox()),
          Center(
//              padding: EdgeInsets.only(top: 400, bottom: 300),
            child: Center(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                  Container(
                    decoration: new BoxDecoration(
//                              color: HexColor('bad6e5').withOpacity(0.9),
//                          color: points < 1000 ? Colors.red.withOpacity(0.7) : Colors.teal.withOpacity(0.7),
                      border: Border.all(color: Colors.white.withOpacity(0.0)),
                      borderRadius: BorderRadius.all(Radius.circular(40)),
                    ),
                  ),
                  Expanded(
                      child: Container(
                          decoration: new BoxDecoration(
//                              color: HexColor('bad6e5').withOpacity(0.9),
                              color: Colors.teal.withOpacity(0.0),
                              border: Border.all(
                                  color: Colors.white.withOpacity(0.0)),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(40))))),
                  Container(
                    decoration: new BoxDecoration(
//                              color: HexColor('bad6e5').withOpacity(0.9),
//                  color:  points < 1000 ? Colors.red.withOpacity(0.7) : Colors.teal.withOpacity(0.7),
                      border: Border.all(color: Colors.white.withOpacity(0.0)),
                      borderRadius: BorderRadius.all(Radius.circular(40)),
                    ),
                  ),
                  Container(
                    child: Opacity(
                      opacity: points < max ? 1 : 0,
                    ),
                  ),
                ])),
          ),
          Padding(padding: EdgeInsets.only(top:20), child: PrettyButton(
            max: max,
            points: points,
            text: "Points:",
          )),
          Center(
              child: FloatingActionButton.extended(
            highlightElevation: 20,
            heroTag: false,
            icon: Icon(CupertinoIcons.play_arrow_solid, color: Colors.black),
            label: Text("Show"),
            backgroundColor: color3,
            splashColor: color3.withOpacity(0.5),
            autofocus: true,
            elevation: 20,
//                        shape: CircleBorder(),
            foregroundColor: Colors.black,
            onPressed: () {

              widget.appAds.showVideoAd(state: this);

            },
          ),),
          points >= 1000 ? Center(
            child: Padding(padding: EdgeInsets.only(top: 100),
            child: FloatingActionButton.extended(
              highlightElevation: 20,
              icon: Icon(Icons.loyalty, color: color3),
              label: Text("Claim Daily Prizepot"),
              backgroundColor: Colors.black,
              splashColor: color3.withOpacity(0.5),
              autofocus: true,
              elevation: 20,
//                        shape: CircleBorder(),
              foregroundColor: color3,
              onPressed: () {
                _addUserToPrizepot();
                setState(() {

                });
              },
            ),)) : SizedBox(),
          Positioned(top: -10.0, right: 0.0, child: IconButton(color: Colors.white, icon: Icon(CupertinoIcons.info), onPressed: () { _showIntroDialog();})),
        ],
      ),
//        bottomNavigationBar: BottomNavigationBarFinal()
    );
  }
}

class CoinStack extends StatelessWidget {

  CoinStack({Key key, this.points, this.sizeDivider, this.factor, this.max, this.multiplier, this.alignment, this.left, this.right});

  int points;
  int sizeDivider;
  final int max;
  double factor;
  double multiplier;
  Alignment alignment;
  double left;
  double right;

  @override
  Widget build(BuildContext context) {
    return Align(alignment: alignment,child: Padding(padding: EdgeInsets.only(left: left, right: right, bottom: max / factor / sizeDivider / multiplier ), child: Container(
      height: (MediaQuery.of(context).size.height / sizeDivider )*0.6 + 20,
//            width: MediaQuery.of(context).size.width / 3,
      color: Colors.transparent,
      child: Opacity(
        opacity: 1,
        child: Image.asset('assets/coins.png',
            height: MediaQuery.of(context).size.height,
            fit: BoxFit.cover),
      ),
    )));
  }

}

class FlippingCoin extends StatelessWidget {

  FlippingCoin({Key key, this.points, this.coindivider, this.animate});

  int points;
  double coindivider;
  bool animate;


  @override
  Widget build(BuildContext context) {
    return Opacity(opacity: animate != null && points < 5000 && points > 0 ? 1.0 : 0.0,
        child: Animator(
            tween: Tween<Offset>(begin: Offset((MediaQuery.of(context).size.width / 50) / coindivider, 0), end: Offset((MediaQuery.of(context).size.width / 50) / coindivider, MediaQuery.of(context).size.height / 50)),
//              : points > 1000 && points <= 2000 ? Tween<Offset>(begin: Offset((MediaQuery.of(context).size.width / 50) / 1, 0), end: Offset((MediaQuery.of(context).size.width / 50) / 1.2, MediaQuery.of(context).size.height / 50))
//              : points > 2000 && points <= 3000 ? Tween<Offset>(begin: Offset((MediaQuery.of(context).size.width / 50) / 2.8, 0), end: Offset((MediaQuery.of(context).size.width / 50) / 2.8, MediaQuery.of(context).size.height / 50))
//              : points > 3000 && points <= 4000 ? Tween<Offset>(begin: Offset((MediaQuery.of(context).size.width / 50) / 0.4, 0), end: Offset((MediaQuery.of(context).size.width / 50) / 0.4, MediaQuery.of(context).size.height / 50))
//              : points > 4000 && points <= 5000 ? Tween<Offset>(begin: Offset((MediaQuery.of(context).size.width / 50) / 13.5, 0), end: Offset((MediaQuery.of(context).size.width / 50) / 13.5, MediaQuery.of(context).size.height / 50))

            duration: Duration(seconds: 5),
            cycles: 1, builder: (anim) =>
            SlideTransition(position: anim,
                child: Animator(
                    tween: Tween<double>(begin: 0, end: 50),
                    duration: Duration(milliseconds: 100000),
                    repeats: 0,
                    builder:

                        (anim) =>
                        Transform.rotate(angle: anim.value, child: Animator(
                            tween: Tween<double>(begin: 0, end: 700),
                            duration: Duration(milliseconds: 100000),
                            repeats: 0,
                            builder:

                                (anim) =>
                                Transform(
                                    transform: Matrix4.rotationX(anim.value),
                                    alignment: Alignment.center,
                                    child: Container(
                                      height: 50,
//                widget.generatedPoints,
//            width: MediaQuery.of(context).size.width / 3,
                                      color: Colors.transparent,
                                      child: Opacity(
                                        opacity: 1,
                                        child: Image.asset('assets/coin.png',
                                            fit: BoxFit.cover),
                                      ),
                                    ))))))));
  }
}

class QualifiedDialog extends StatelessWidget {

  QualifiedDialog({Key key, this.text});
  String text;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Dialog(
        elevation: 0,
        backgroundColor: Colors.transparent,
        child: Container(
          padding: EdgeInsets.only(right: 16.0),
          height: 150,
          decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.all(
                  Radius.circular(50))
          ),
          child: Row(
            children: <Widget>[
              SizedBox(width: 20.0),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(height: 10.0),
                    Flexible(
                      child: Align(alignment: Alignment.center, child: Text(
                          "Congratulations! You have successfully qualified for the" + text + "Pricepot!", style: TextStyle(color: Colors.white, fontSize: 20,))),
                    ),
                    Row(children: <Widget>[
                      Expanded(
                        child: RaisedButton(
                          child: Text("ok"),
                          color: Colors.green,
                          colorBrightness: Brightness.dark,
                          onPressed: (){Navigator.of(context).pop(false);},
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
                        ),
                      ),
                    ],),
                    SizedBox(height: 10.0)
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
