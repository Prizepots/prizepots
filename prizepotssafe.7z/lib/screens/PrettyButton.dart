import 'package:prizepots/main.dart';
import 'package:flutter/material.dart';

class PrettyButton extends StatefulWidget {
  PrettyButton(
      {Key key,
      this.text,
      this.points,
      this.icon,
      this.color,
      this.path,
        this.max})
      : super(key: key);
  String text;
  int points;
  Icon icon;
  Color color;
  String path;
  int max;

  @override
  _PrettyButtonState createState() => _PrettyButtonState();
}

class _PrettyButtonState extends State<PrettyButton> {

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 12), child:
    Center(child: Align(alignment: Alignment.topCenter, child: Container(
        height: 30,
        width: MediaQuery.of(context).size.width - 24,
        decoration: BoxDecoration(color: Colors.white, border: Border.all(
            color: Colors.white.withOpacity(1.0)),
    borderRadius: BorderRadius.all(Radius.circular(40))),

        child: Padding(
            padding:
                EdgeInsets.only(left: 12.0, top: 0.0, right: 12.0, bottom: 0.0),
                child: Row(children: <Widget>[
//              Padding(padding: EdgeInsets.all(8.0)),
                  Container(

                      child:
//                          Transform(alignment: Alignment.center,
//                              transform: Matrix4.rotationY(math.pi), child:
//                      Icon(Icons.euro_symbol)),
                      Align(alignment: Alignment.center, child: Text(
                        widget.text ?? "",
                        style: TextStyle(
                          fontFamily: 'ColaborateThin',
                          fontWeight: FontWeight.w300,
                          fontSize: 20.0,
                          color: textColordark.withOpacity(1),
                          letterSpacing: 0.3,
                        ),
                      ),)
                  ),
                      Expanded(
                        child:
                        Center(child:Text(
                         widget.points.toString() + " / " + widget.max.toString(),
                          style: TextStyle(
                            fontFamily: 'ColaborateThin',
                            fontWeight: FontWeight.w300,
                            fontSize: 20.0,
                            color: textColordark.withOpacity(1),
                            letterSpacing: 0.3,
                          ),),

                        ),
                      ),

                       Container(
                        child: Opacity(
                            opacity: 1,
                            child: widget.points >= widget.max ? Icon(Icons.check, color: Colors.teal) : Icon(Icons.block, color:Colors.red),
//                            Image.asset(
//                                widget.path ?? 'assets/majorPrizepot.png')
////                        widget.icon,
                            ),
                      ),


                ]))))));
  }

//  void doSomething() {
//    widget.pressed = !widget.pressed;
//    setState(() {});
//  }
}
