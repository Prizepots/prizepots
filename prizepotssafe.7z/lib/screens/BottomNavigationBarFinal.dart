import 'package:prizepots/main.dart';
import 'package:prizepots/screens/Home.dart';
import 'package:prizepots/screens/LoginView.dart';
import 'package:prizepots/screens/SlideLeftRoute.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class BottomNavigationBarFinal extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
        shape: CircularNotchedRectangle(),
        color: Colors.black.withOpacity(1),
        child: Container(
            height: 60.0,
            child: new Row(children: <Widget>[
              Expanded(
                  child: InkWell(customBorder: CircleBorder(),
                      highlightColor: color3,
                      onLongPress: () {
//                        countButton(3);
                      }, child:
                      RaisedButton(
                      shape: new CircleBorder(),

                onPressed: () {Navigator.push(context,
                    SlideLeftRoute(page: LoginView(isCloseable: true,)));},
                color: Colors.black,
                child: Icon(Icons.group, color: color3),
              ))),
              Expanded(
                child: Container(
                  height: 50,
                ),
              ),
              Expanded(
                  child: InkWell(customBorder: CircleBorder(),
                    highlightColor: color3,
                    onLongPress: () {
//                        countButton(3);
                    },
                  child: RaisedButton(
                    shape: new CircleBorder(),
                    onPressed: () {Navigator.push(context,
    CupertinoPageRoute(builder: (context) => LoginView(isCloseable: true,)));},
                color: Colors.black,
                child: Icon(Icons.account_balance_wallet, color: color3),
    )))
            ])));
  }
}
